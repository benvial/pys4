#define F77_FUNC(l,u) l##_

#define PACKAGE "S4"
#define PACKAGE_BUGREPORT "vkl@stanford.edu"
#define PACKAGE_NAME "S4"
#define PACKAGE_STRING "S4 1.1.1"
#define PACKAGE_TARNAME "S4"
#define PACKAGE_URL ""
#define PACKAGE_VERSION "1.1.1"
#define VERSION "1.1.1"

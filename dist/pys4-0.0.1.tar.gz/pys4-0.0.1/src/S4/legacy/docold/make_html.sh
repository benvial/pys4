#!/bin/sh
makepage < bugs.md > bugs.html
makepage < changelog.md > changelog.html
makepage < dev_info.md > dev_info.html
makepage < formulations.md > formulations.html
makepage < index.md > index.html
makepage < license.md > license.html
makepage < s4_lua_api.md > s4_lua_api.html
makepage < faq.md > faq.html
